g++ nn.cc -o nn -std=c++11 -g
