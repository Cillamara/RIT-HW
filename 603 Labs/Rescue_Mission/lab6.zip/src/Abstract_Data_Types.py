"""
CSCI-603 Lab 6: Rescue Mission
Author: Liam Cui
"""
from typing import Any

class LinkedNode:
    """
    Linked Node Class. Represents single linked data structure.
    """
    __slots__ = '_value', '_link'
    _value: Any
    _link: 'LinkedNode'

    def __init__(self, value: Any, link: 'LinkedNode'):
        """
        create a linked node
        :param value: any value
        :param link: any other linked node or None
        """
        self._value = value
        self._link = link

    def get_value(self) -> Any:
        """
        value getter
        :return: value of node
        """
        return self._value

    def get_link(self) -> 'LinkedNode':
        """
        link getter
        :return: return the link
        """
        return self._link

    def set_link(self, node: 'LinkedNode') -> None:
        """
        Sets link to another linked node.
        :param node: a linked node
        """
        self._link = node

    def __str__(self) -> str:
        return str(self._value)

    def __repr__(self) -> str:
        return "LinkedNode(" + repr(self._value) + "," + repr(self._link) + ")"

class Stack:
    """
    Stack Class. Uses LinkedNode to construct a LIFO data structure.
    """
    __slots__ = '_top', '_size'
    _top: 'LinkedNode'
    _size: int

    def __init__(self) -> None:
        """create a new empty stack."""
        self._top = None
        self._size = 0

    def __str__(self) -> str:
        result = "Stack["
        n = self._top
        while n is not None:
            result += str(n.get_value())
            n = n.get_link()
        result += " ]"
        return result

    def is_empty(self) -> bool:
        """
        is the stack empty?
        :return: if the stack is empty?
        """
        return self._top is None

    def push(self, newValue: Any) -> None:
        """
        Add new value to the top of the stack.
        :param newValue: the new value
        """
        self._top = LinkedNode(newValue, self._top)
        self._size += 1

    def pop(self) -> Any:
        """
        Remove and return the top value from the stack.
        :return: top value from the stack
        """
        assert not self.is_empty(), "Cannot pop from empty stack"
        temp = self._top.get_value()
        self._top = self._top.get_link()
        self._size -= 1
        return temp

    def peek(self) -> Any:
        """
        check top value of the stack
        :return: top value of the stack
        """
        assert not self.is_empty(), "Cannot peek from empty stack"
        return self._top.get_value()

    def get_size(self) -> int:
        """
        get size of the stack
        :return: size of the stack
        """
        return self._size

class Queue:
    """
    Queue Class. Uses LinkedNode to construct a FIFO data structure.
    """
    __slots__ = '_front', '_back', '_size'
    _front: 'LinkedNode'
    _back: 'LinkedNode'
    _size: int

    def __init__(self):
        """create a new empty queue."""
        self._front = None
        self._back = None
        self._size = 0

    def __str__(self) -> str:
        result = "Queue["
        n = self._front
        while n is not None:
            result += str(n.get_value())
            n = n.get_link()
        result += " ]"
        return result

    def is_empty(self) -> bool:
        """
        is the queue empty?
        :return: if the queue is empty
        """
        return self._front is None

    def enqueue(self, newValue: Any) -> None:
        """
        Add new value to the front of the queue.
        :param newValue: the new value
        """
        newNode = LinkedNode(newValue, None)
        if self._front is None:
            self._front = newNode
        else:
            self._back.set_link(newNode)
        self._back = newNode
        self._size += 1

    def dequeue(self) -> Any:
        """
        Remove and return the top value from the queue.
        :return: the top value from the queue
        """
        assert not self.is_empty(), "Cannot dequeue from empty queue"
        front = self._front.get_value()
        self._front = self._front.get_link()
        if self._front is None:
            self._back = None
        self._size -= 1
        return front

    def peek(self) -> Any:
        """
        check top of the queue
        :return: top value of the queue
        """
        assert not self.is_empty(), "Cannot peek from empty queue"
        return self._front.get_value()

    def get_size(self) -> int:
        """
        get size of the queue
        :return: size of the queue
        """
        return self._size



