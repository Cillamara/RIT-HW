"""
CSCI-603 Lab 6: Rescue Mission
Author: Liam Cui
"""
import builtins
import enum

class Role(enum.Enum):
    """
    An enum to represent the possible roles of a player
    """
    GUERRILLA = 4
    HOSTAGE = 3
    PREDATOR = 1
    SOLDIER = 2


class Player(builtins.object):
    """
    A class to represent a player. Every player has:
    - an id
    - a role: Predator, Soldier, Hostage or Guerrilla
    Every player has a unique combination of id and role.
    """
    #Data and other attributes defined here:
    GUERRILLA_CHANCE_TO_BEAT_SOLDIER = 20
    PREDATOR_CHANCE_TO_BEAT_HOSTAGE = 50
    PREDATOR_CHANCE_TO_BEAT_SOLDIER = 75
    __slots__ = "_id", "_role"
    _id: int
    _role: Role

    def __init__(self, id: int, role: Role):
        """
        Create a new player.

        :param id: the id of the player
        :param role: the role of the player
        """
        self._id = id
        self._role = role

    def __str__(self):
        """
        The string representation of a player is:
        "{role} #{id}"

        :return: the player string
        """
        return str(self._role.name) + " #" + str(self._id)

    def print_victory_message(self, opponent: 'Player') -> None:
        """
        If the player is triumphant over the opponent, it displays the message:
        "{player} defeats {opponent}"

        :param opponent: the defeated player
        :return: None
        """
        print(str(self) + " defeats " + str(opponent))

