"""
CSCI-603 Lab 6: Rescue Mission
Author: Liam Cui

The rescue mission simulation main file. Runs in command line with arguments
for seed#, # of hostages, # of soldiers, and # of guerrillas. This program is a
turn-based simulation for hostage extraction based on the hit movie Predator.
"""
from Chopper import Chopper
from Enemy_Base import *
from Bunker import *
import random
import sys

class RescueMission(builtins.object):
    """
    The main class that simulates the rescue mission.
    """
    __slots__ = "_eb", "_bunker", "_chopper"
    _eb: Enemy_Base
    _bunker: Bunker
    _chopper: Chopper

    def __init__(self, seed: int, num_hostages: int, num_soldiers: int,
                 num_guerrillas: int):
        """
        Create the rescue mission. This method is responsible for seeding the
        random number generator and initializing all the supporting classes in
        the simulation: Chopper, Bunker, Enemy_Base and Predator.

        :param seed: the seed for the random number generator
        :param num_hostages: the number of hostages
        :param num_soldiers: the number of soldiers
        :param num_guerrillas: the number of guerrillas
        """
        random.seed(seed)
        self._eb = Enemy_Base(num_hostages, num_guerrillas, random.Random())
        self._bunker = Bunker(num_soldiers)
        self._chopper = Chopper()

    def run_simulation(self) -> None:
        """
        The main rescue mission loop runs here. The simulation runs until
        either all the hostages have been rescued, or there are no more
        soldiers left to rescue hostages.

        :return: None
        """
        print("Get to the choppa!")
        predator = Player(1, Role.PREDATOR)
        # while there are hostages and soldiers remaining
        while self._eb.get_num_hostages() != 0 and self._bunker.has_soldiers():
            print("Statistics:", self._eb.get_num_hostages(),
                  "hostage/s remain,", self._bunker.get_num_soldiers(),
                  "soldier/s remain,", self._eb.get_num_guerrillas(),
                  "guerrilla/s remain,", self._chopper.get_num_rescued(),
                  "rescued")
            soldier = self._bunker.deploy_next_soldier()
            # returns None if guerilla wins the roll
            hostage = self._eb.rescue_hostage(soldier)
            if hostage is not None:
                print(str(hostage) + " rescued from enemy base by " +
                      str(soldier))
                roll = random.randint(1, 100)
                print(str(soldier) + " encounters the predator who rolls a",
                      roll)
                # if Predator loses to soldier
                if roll > Player.PREDATOR_CHANCE_TO_BEAT_SOLDIER:
                    soldier.print_victory_message(predator)
                    self._bunker.fortify_soldier(soldier)
                    rescued = True
                else:
                    predator.print_victory_message(soldier)
                    roll = random.randint(1, 100)
                    print(str(hostage)+" encounters the predator who rolls a",
                          roll)
                    # if predator loses to hostage
                    if roll > Player.PREDATOR_CHANCE_TO_BEAT_HOSTAGE:
                        hostage.print_victory_message(predator)
                        rescued = True
                    else:
                        predator.print_victory_message(hostage)
                        rescued = False
                if rescued:
                    self._chopper.board_passenger(hostage)
        # If there are any soldiers left over, send them to the chopper
        while self._eb.get_num_hostages() == 0 and self._bunker.has_soldiers():
            soldier = self._bunker.deploy_next_soldier()
            self._chopper.board_passenger(soldier)
        if not self._chopper.is_empty():
            self._chopper.rescue_passengers()
        print("Statistics:", self._eb.get_num_hostages(), "hostage/s remain,",
              self._bunker.get_num_soldiers(), "soldier/s remain,",
              self._eb.get_num_guerrillas(), "guerrilla/s remain,",
              self._chopper.get_num_rescued(), "rescued")

def main():
    """
    The main function.
    """
    RescueMission(int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]),
                  int(sys.argv[4])).run_simulation()

if __name__ == "__main__":
    main()


