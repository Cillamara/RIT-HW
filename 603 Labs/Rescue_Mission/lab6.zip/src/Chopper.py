"""
CSCI-603 Lab 6: Rescue Mission
Author: Liam Cui
"""
import builtins
from Abstract_Data_Types import Stack

class Chopper(builtins.object):
    """
    A class to represent the chopper. The chopper can hold up to 6 passengers
    aligned in a single columns of seats. There is only one door to the chopper
    that is accessible by the passengers. When they enter the chopper, the
    occupy the seat closest to the door and any existing passengers move one
    seat down. In order to preserve fuel, the chopper will only fly the
    passengers away to safety if the chopper is full, or it is the last group
    of people to rescue.
    """
    __slots__ = "_seats", "_num_rescued"
    _seats: Stack
#MAX_OCCUPANCY = 6
    def __init__(self):
        """
        Create a new empty chopper.
        """
        self._seats = Stack()
        self._num_rescued = 0

    def board_passenger(self, player) -> None:
        """
        Board a passenger onto the chopper. The passenger boards
        the chopper and occupies the front seat, making everyone else in the
        chopper move down a seat.  When the passenger boards the chopper
        display the message:
        "{passenger} boards the chopper!"

        :param player: The player boarding the chopper
        :return: None
        """
        self._seats.push(player)
        self._num_rescued += 1
        print(str(player) + " boards the chopper!")
        if self.is_full():
            self.rescue_passengers()


    def get_num_rescued(self) -> int:
        """
        Get the number of passengers that were rescued.

        :return: the number of rescued passengers
        """
        return self._num_rescued

    def is_empty(self) -> bool:
        """
        Is the chopper empty?

        :return: whether the chopper is empty
        """
        return self._seats.get_size() == 0

    def is_full(self) -> bool:
        """
        Is the chopper full?

        :return: whether the chopper has reached max occupancy or not
        """
        return self._seats.get_size() == 6

    def rescue_passengers(self) -> None:
        """
        When the chopper is full, or it is the last group of people to be
        rescued, it will fly away and rescue the passengers.  Each passenger
        exits the chopper in the reverse order they entered it, e.g. the last
            passenger to enter exits first.
        As each passenger exits the chopper, print the message:
        "Chopper transported {passenger} to safety!"

        :return: None
        """
        while not self._seats.is_empty():
            player = self._seats.pop()
            print("Chopper transported " + str(player) + " to safety!")

