"""
CSCI-603 PreTee Lab
Author: RIT CS

A custom exception class for representing a runtime error.
"""

class RuntimeError(Exception):
    pass