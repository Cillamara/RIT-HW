"""
CSCI-603 PreTee Lab
Author: RIT CS

A custom exception class for representing a syntax error.
"""


class SyntaxError(Exception):
    pass
