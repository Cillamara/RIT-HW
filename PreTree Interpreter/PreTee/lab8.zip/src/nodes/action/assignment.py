"""
CSCI-603 PreTee Lab
Author: Liam Cui

An assignment statement of the prefix form:
    '= {variable} {expression}'
"""

from nodes.action.action_node import ActionNode
from nodes.expression.math_node import MathNode
from nodes.expression.variable import Variable
from errors import syntax_error


class Assignment(ActionNode):
    """
    represents a variable assignment in the pretree.
    inherits from ActionNode.

    :raises syntax_error.SyntaxError: If assignment target is not a variable
    """
    __slots__ = '_variable', '_expression', '_sym_tbl', '_token'
    _variable: MathNode
    _expression: MathNode
    _sym_tbl: dict[str, int]
    _token: str

    def __init__(self, variable: Variable, expression, sym_tbl: dict[str, int],
                 token: str):
        """
        Initialize an Assignment node.

        :param variable: The variable node
        :param expression: The expression that represents the value of
            the variable
        :param sym_tbl: The symbol table which associates variable
            names with values (int)
        :param token: The character associated with assignment
            when emitting (str)
        :exception: raises syntax_error.SyntaxError if there is an assignment
            to a non-variable, with the message, 'Bad assignment to non-variable'
        :exception: raises syntax_error.SyntaxError if the expression is not a
            math expression with the message, 'Bad assignment expression'.
        :return: None
        """
        if not isinstance(variable, Variable):
            raise syntax_error.SyntaxError("Bad assignment to non-variable")
        super().__init__(expression)
        self._variable = variable
        self._sym_tbl = sym_tbl
        self._token = token

    def emit(self) -> str:
        """
        Returns a string in infix form:
            '{variable-emit} {token} {expression-token}'

        :return: The infix string (str)
        """
        return f"{self._variable.emit()} {self._token} {self._expression.emit()}"

    def execute(self) -> None:
        """
        Evaluates the expression and stores the result in the symbol table
        for the variable name.

        :exception: runtime_error.RunTimeError may be raised if an assignment
            to an invalid expression is made (e.g. unknown variable name or
            bad expression).
        :return: None
        """
        self._sym_tbl[self._variable.get_id()] = self._expression.evaluate()