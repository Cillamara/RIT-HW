"""
CSCI-603 PreTee Lab
Author: Liam Cui

A print statement is of the prefix form, where {expression} is optional:

    '@ {expression}'
"""

from nodes.action.action_node import ActionNode
from nodes.expression.math_node import MathNode


class Print(ActionNode):
    """
    This class represents the print statements.
    Inherits from ActionNode.
    """
    __slots__ = ('_expression',)


    def __init__(self, expression: MathNode =None):
        """
        Initialize a PrintNode
        :param expression: A valid expression node (LiteralNode, VariableNode,
            MathNode)

        :return: None
        """
        super().__init__(expression)

    def execute(self) -> None:
        """
        If the expression is not present, just prints a newline, otherwise
        it prints the evaluation of the expression in string form.

        :return: None
        """
        if self._expression:
            print(self._expression.evaluate())
        else:
            print()

    def emit(self) -> str:
        """
        Returns a string in infix form, where {expression} is optional:
            print {expression-emit}

        :return: The infix string (str)
        """
        if self._expression:
            return f"print {self._expression.emit()}"
        return "print"