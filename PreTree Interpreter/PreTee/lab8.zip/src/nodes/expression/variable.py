"""
CSCI-603 PreTee Lab
Author: Liam Cui

A variable expression is a legal identifier in Python:
    '{id}'
"""

from errors import runtime_error
from nodes.expression.math_node import MathNode

class Variable(MathNode):
    """
    Represents an expression variable which is paired with an integer value.
    Inherits from MathNode.

    :raises: RuntimeError when expression variable is undefined.
    """
    __slots__ = '_id', '_sym_tbl'
    _id: str
    _sym_tbl: dict[str, int]

    def __init__(self, var_id: str, sym_tbl: dict[str, int]):
        """
        Initialize a VariableNode.

        :param id: The name of the variable
        :param sym_tbl: The symbol table which associates variable
        names (key=str) with values (value=int)
        :return: None
        """
        self._id = var_id
        self._sym_tbl = sym_tbl

    def emit(self) -> str:
        """
        Return the name of the variable.

        :return: The variable name
        """
        return self._id

    def evaluate(self) -> int:
        """
        Evaluates the variable to retrieve its stored value.

        :exception: raises a runtime_error.RuntimeError if the variable name
            is not in the symbol table, with the message,
            'Unrecognized variable {variable}'
        :return: The value associated with the variable (int)
        """
        if self._id not in self._sym_tbl:
            raise runtime_error.RuntimeError(f"Unrecognized variable {self._id}")
        return self._sym_tbl[self._id]

    def get_id(self):
        """
        Return the name of the variable
        """
        return self._id