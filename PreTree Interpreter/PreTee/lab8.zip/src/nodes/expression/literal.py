"""
CSCI-603 PreTee Lab
Author: Liam Cui

A literal expression is of the prefix form, where {value} is an integer:
    '{value}'
"""
from nodes.expression.math_node import MathNode

class Literal(MathNode):
    """
    Represents an integer literal
    Inherits from MathNode.
    """
    __slots__ = '_value'
    _value: int

    def __init__(self, val: int):
        """
        Initialize a Literal node.
        :param val: the value (int)
        :return: None
        """
        self._value = val

    def emit(self) -> str:
        """
        Return a string representation of the value, e.g.:
            '{value}'
        :return: the string form of the value
        """
        return str(self._value)

    def evaluate(self) -> int:
        """
        Returns the value of the literal.
        :return: The value (int)
        """
        return self._value