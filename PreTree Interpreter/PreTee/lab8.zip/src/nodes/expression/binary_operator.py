"""
CSCI-603 PreTee Lab
Author: Liam Cui

A math expression is of the prefix form:

    '{operator} {left-expression} {right-expression}'
"""

from errors import runtime_error
from nodes.expression.math_node import MathNode


class BinaryOperator(MathNode):
    """
        Represents binary mathematical operations.
        Inherits from MathNode.

        :raises: RuntimeError for division by zero
        """
    __slots__ = '_left', '_right', '_op'
    _left: MathNode
    _right: MathNode
    _op: str #an operator token

    def __init__(self, left: MathNode, right: MathNode, op: str):
        """
        Initialize a Binary operator node.

        :param left: the left expression (LiteralNode, MathNode, VariableNode)
        :param right: the right expression (LiteralNode, MathNode, VariableNode)
        :param op: the character for the math operation (str)
        :return: None
        """
        self._left = left
        self._right = right
        self._op = op

    def emit(self) -> str:
        """
        Returns a parenthesized string with the emits of the left and right
        expressions,
            e.g.: '({left-emit} {token} {right-emit})'

        :return: the string of the parenthesized expression
        """
        return f"({self._left.emit()} {self._op} {self._right.emit()})"

    def evaluate(self) -> int:
        """
        Evaluates the math expression and returns the result.

        :exception: raises a runtime_error.RuntimeError if division by zero
            is attempted, with the message, 'Division by zero error'
        :return: The result of performing the math operation (int)
        """

        left_val = self._left.evaluate()
        right_val = self._right.evaluate()
        match self._op:
            case '+':
                return left_val + right_val
            case '-':
                return left_val - right_val
            case '*':
                return left_val * right_val
            case '//':
                if right_val == 0:
                    raise runtime_error.RuntimeError("Division by zero")
                return left_val // right_val
            case _:
                raise runtime_error.RuntimeError(
                    f"Unknown operator {self._op}")

