"""
CSCI-603 PreTee Lab
Author: RIT CS
Author: Liam Cui

The main program and class for a prefix expression interpreter of the
PreTee language.

Usage: python3 pretee.py source-file.pre
"""
from queue import Queue
import sys  # argv
import errors.runtime_error  # runtime_error.RuntimeError
from errors import runtime_error
from nodes.action.assignment import Assignment
from nodes.expression.binary_operator import BinaryOperator
from nodes.expression.literal import Literal
from nodes.expression.variable import Variable
from src.errors import syntax_error
from nodes.action.print import Print


class PreTee:
    """
    The PreTee class consists of:
    - the name of the source file (str)
    - a list where each element represents each line in the src as a queue
        that stores the space delimited content of each line as tokens.
    - the symbol table (dict[key=str, valur=int])
    - the parse trees: a list of the root nodes for valid, non-commented
        line of code
    - the line number: when parsing, the current line number in the source
        file (int)
    - a syntax error flag: indicates whether a syntax error occurred during
        parsing (bool).  If there is a syntax error, all the parse trees will
        not be evaluated
    """
    __slots__ = ('_list_of_token_Qs', '_symbol_table', '_parse_trees',
                 '_line_number', '_syntax_error')

    # the tokens in the language for statements
    COMMENT_TOKEN = '#'
    ASSIGNMENT_TOKEN = '='
    PRINT_TOKEN = '@'

    def __init__(self, src_file: str):
        """
        Initialize the parser.
        :param src_file: the source file (string)
        """
        self._list_of_token_Qs = []
        self._symbol_table = {}
        self._parse_trees = []
        self._line_number = 0
        self._syntax_error = False
        with open(src_file, 'r') as file:
            for line in file:
                tokens = line.strip().split()
                if not tokens:
                    continue
                queue = Queue()
                for token in tokens:
                    queue.put(token)
                self._list_of_token_Qs.append(queue)

    def parse(self) -> None:
        """
        The public parse is responsible for looping over the lines of
        source code and constructing the parse trees. All parse trees
        are appended to a list. Calls upon private _parse_expression() function
        It needs to handle and display any syntax_error.SyntaxError
        exceptions that get raised.
        :return: None
        """
        for queue in self._list_of_token_Qs:
            self._line_number += 1
            if queue.empty():
                continue
            try:
                token = queue.get()
                match token:
                    case self.COMMENT_TOKEN:
                        continue
                    case self.ASSIGNMENT_TOKEN:
                        if queue.empty():
                            raise syntax_error.SyntaxError(
                                "Incomplete statement")
                        variable = queue.get()
                        if not variable.isidentifier():
                            raise syntax_error.SyntaxError(
                                f"Bad assignment to non-variable")
                        variable_node = Variable(variable, self._symbol_table)
                        expr = self._parse_expression(queue)
                        self._parse_trees.append(Assignment(variable_node,
                                    expr, self._symbol_table,
                                    self.ASSIGNMENT_TOKEN))
                    case self.PRINT_TOKEN:
                        if queue.empty():
                            expression = None
                        else:
                            expression = self._parse_expression(queue)
                        self._parse_trees.append(Print(expression))
                    case _:
                        raise syntax_error.SyntaxError(
                            f"Illegal action {token}")
            except syntax_error.SyntaxError as e:
                self._syntax_error = True
                print(f"Syntax error line {self._line_number}: {e}")
            except runtime_error.RuntimeError as e:
                print(f"*** Runtime error: {e}")

    def _parse_expression(self, queue: Queue):
        """
        Recursively parses mathematical expressions from a prefix token queue.
        This function is not responsible for variable assignment.
        This function is called upon by parse().

        :param queue: an empty queue
        :return: a MathNode object representing an expression tree node.
        :raises: SyntaxError for incomplete statements and invalid tokens
        """
        if queue.empty():
            raise syntax_error.SyntaxError("Incomplete statement")
        token = queue.get()
        if PreTee.is_digit(token):
            return Literal(int(token))
        elif token in {'+', '-', '*', '//'}:
            left = self._parse_expression(queue)
            right = self._parse_expression(queue)
            return BinaryOperator(left, right, token)
        elif token.isidentifier():
            return Variable(token, self._symbol_table)
        else:
            raise syntax_error.SyntaxError(f"Invalid token {token}")


    def emit(self) -> None:
        """
        Prints an infix string representation of the source code that
        is contained as root nodes in the list of parse trees.
        :return: None
        """
        for node in self._parse_trees:
            if node is not None:
                print(node.emit())
            else:
                print("print")

    def evaluate(self):
        """
        Prints the results of evaluating the root notes from the list of parse
        trees. This can be viewed as executing the compiled code.  If a
        runtime error happens, execution halts.

        :exception: runtime_error.RunTimeError may be raised if a
            parse tree encounters a runtime error
        :return None
        """
        if self._syntax_error:
            pass
        for node in self._parse_trees:
            try:
                if node is not None:
                    node.execute()
                else:
                    print("")
            except runtime_error.RuntimeError as e:
                print(f"*** Runtime error: {e}")
                break

    @staticmethod
    def is_digit(token: str) -> bool:
        """
        Helper method to validate numeric tokens. Returns true if the token is
        a valid integer.
        :param token: The string to validate
        :return: whether the token is an integer
        """
        try:
            int(token)
            return True
        except ValueError:
            return False


def main():
    """
    The main function prompts for the source file, and then does:
        1. Compiles the prefix source code into parse trees
        2. Prints the source code as infix
        3. Executes the compiled code
    :return: None
    """
    if len(sys.argv) != 2:
        print('Usage: python3 pretee.py source-file.pre')
        return

    pretee = PreTee(sys.argv[1])
    print('PRETEE: Compiling', sys.argv[1] + '...')
    pretee.parse()
    print('\nPRETEE: Infix source...')
    pretee.emit()
    print('\nPRETEE: Executing...')
    try:
        pretee.evaluate()
    except errors.runtime_error.RuntimeError as e:
        # on first runtime error, the supplied program will halt execution
        print('*** Runtime error:', e)


if __name__ == '__main__':
    main()
